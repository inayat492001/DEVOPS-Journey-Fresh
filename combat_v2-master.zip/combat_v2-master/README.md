# CODE COMBAT v2.0 🎮

Real-time competitive coding platform.
**Server-side deterministic evaluation** via isolated `vm.Context` + `evaluator.js`.

## Project Structure
```
code-combat/
├── server.js                    # Node.js + Socket.io backend  (v2)
├── evaluator.js                 # Deterministic VM evaluation engine
├── package.json
├── coding-combat-host.html      # Host dashboard
├── coding-combat-player.html    # Player page (?slot=1..5)
├── coding-combat-player2.html   # Backward-compatible Player 2 shortcut
├── Dockerfile
├── docker-compose.yml
├── nginx.conf
├── .env.example
├── .dockerignore / .gitignore
├── ecosystem.config.js          # PM2 (no-Docker VPS)
├── deploy.sh                    # One-click VPS script
├── fly.toml                     # Fly.io
├── render.yaml                  # Render.com
├── railway.json                 # Railway
├── .github/workflows/deploy.yml # GitHub Actions CI/CD
└── .ebextensions/               # AWS Elastic Beanstalk
    └── nodecommand.config
```

## Run Locally
```bash
npm install
node server.js
# Host:     http://localhost:3000/coding-combat-host.html
# Player 1: http://localhost:3000/coding-combat-player.html?slot=1
# Player 2: http://localhost:3000/coding-combat-player.html?slot=2
# Player 3: http://localhost:3000/coding-combat-player.html?slot=3
# Player 4: http://localhost:3000/coding-combat-player.html?slot=4
# Player 5: http://localhost:3000/coding-combat-player.html?slot=5
# Health:   http://localhost:3000/health
```

## Docker Compose
```bash
cp .env.example .env
docker compose up -d
docker compose logs -f
```

## VPS One-Click
```bash
chmod +x deploy.sh && ./deploy.sh
```

## Fly.io
```bash
flyctl auth login && flyctl launch && flyctl deploy
```

## Render.com
Push to GitHub → New Blueprint → select repo (reads render.yaml)

## Railway
```bash
railway login && railway init && railway up
```

## AWS Elastic Beanstalk
```bash
eb init code-combat --platform node.js-20 --region us-east-1
eb create production && eb deploy
```

## Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| PORT | 3000 | Server port |
| NODE_ENV | production | Environment |
| CORS_ORIGIN | * | Restrict to your domain in production |

## What evaluator.js fixes
| Root Cause | Fix Applied |
|-----------|-------------|
| Input mutation (arr.sort()) | `deepClone()` before every test case |
| Shared state between tests | Fresh `vm.Context` per test case |
| `JSON.stringify` comparison | `deepEqual()` handles NaN, -0, undefined |
| Infinite loops | Hard 3s timeout via `vm.runInContext` |
| Prototype pollution | Snapshot before/after execution |
| Syntax errors crash server | `vm.Script` pre-validation |
| Dangerous globals | process/require/fetch blocked from sandbox |
