'use strict';

const fs = require('fs/promises');
const os = require('os');
const path = require('path');
const vm = require('vm');
const v8 = require('v8');
const { spawn } = require('child_process');

const DEFAULT_TIMEOUT_MS = 3000;
const COMPILE_TIMEOUT_MS = 10000;
const MAX_CODE_LENGTH = 50_000;
const MAX_LOG_CHARS = 5_000;
const RESULT_MARKER = '__RESULT__';

function deepClone(value) {
  if (typeof structuredClone === 'function') {
    try { return structuredClone(value); } catch (_) {}
  }
  try { return v8.deserialize(v8.serialize(value)); } catch (_) {}
  return JSON.parse(JSON.stringify(value));
}

function deepEqual(a, b) {
  if (a === b) return true;
  if (typeof a === 'number' && typeof b === 'number') {
    if (isNaN(a) && isNaN(b)) return true;
    if (a === 0 && b === 0) return (1 / a) === (1 / b);
  }
  if (a == null || b == null) return a === b;
  if (typeof a !== typeof b) return false;
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    return a.every((v, i) => deepEqual(v, b[i]));
  }
  if (typeof a === 'object') {
    const ka = Object.keys(a).sort();
    const kb = Object.keys(b).sort();
    if (ka.length !== kb.length || ka.some((k, i) => k !== kb[i])) return false;
    return ka.every(k => deepEqual(a[k], b[k]));
  }
  return false;
}

function safeStr(v) {
  if (v === undefined) return 'undefined';
  if (v === null) return 'null';
  if (typeof v === 'number') {
    if (isNaN(v)) return 'NaN';
    if (!isFinite(v)) return v > 0 ? 'Infinity' : '-Infinity';
    if (Object.is(v, -0)) return '-0';
  }
  try { return JSON.stringify(v); } catch (_) { return String(v); }
}

function normalizeTextOutput(value) {
  return String(value ?? '').replace(/\r/g, '').trimEnd();
}

function validateSyntax(code) {
  try {
    new vm.Script(code, { filename: 'solution.js' });
    return { valid: true };
  } catch (e) {
    return { valid: false, error: `SyntaxError: ${e.message}` };
  }
}

function snapshotProtos() {
  return {
    arr: Object.getOwnPropertyNames(Array.prototype).length,
    obj: Object.getOwnPropertyNames(Object.prototype).length,
    fn: Object.getOwnPropertyNames(Function.prototype).length,
  };
}

function wasPolluted(before, after) {
  return before.arr !== after.arr || before.obj !== after.obj || before.fn !== after.fn;
}

function runOneTestCase(userCode, testCase, timeoutMs) {
  const inputClone = deepClone(testCase.input);
  const expectedClone = deepClone(testCase.expected);
  const logs = [];
  const captureConsole = {
    log: (...a) => { if (logs.join('').length < MAX_LOG_CHARS) logs.push(a.map(safeStr).join(' ')); },
    error: (...a) => { if (logs.join('').length < MAX_LOG_CHARS) logs.push('[ERR] ' + a.map(safeStr).join(' ')); },
    warn: (...a) => { if (logs.join('').length < MAX_LOG_CHARS) logs.push('[WARN] ' + a.map(safeStr).join(' ')); },
    info: (...a) => { if (logs.join('').length < MAX_LOG_CHARS) logs.push('[INFO] ' + a.map(safeStr).join(' ')); },
    dir: () => {},
    table: () => {},
  };

  const sandbox = vm.createContext({
    console: captureConsole,
    Math, JSON, Date,
    parseInt, parseFloat, isNaN, isFinite,
    Number, String, Boolean, Array, Object,
    Map, Set, WeakMap, WeakSet,
    Symbol, BigInt,
    Error, TypeError, RangeError, ReferenceError, SyntaxError,
    Promise,
    __input__: inputClone,
    __result__: undefined,
  });

  const protoBefore = snapshotProtos();
  const t0 = Date.now();
  let result;
  let error = null;
  let reason = 'ok';

  try {
    vm.runInContext(
      `
      (function() {
        'use strict';
        ${userCode}
        if (typeof solution !== 'function') {
          throw new ReferenceError('No function named "solution" found. Name your function: function solution(...) {}');
        }
        if (__input__ !== null && typeof __input__ === 'object' && !Array.isArray(__input__) && 'target' in __input__) {
          __result__ = solution(__input__.arr, __input__.target);
        } else {
          __result__ = solution(__input__);
        }
      })();
      `,
      sandbox,
      { filename: 'solution.js', timeout: timeoutMs, breakOnSigint: true }
    );

    result = sandbox.__result__;
    if (wasPolluted(protoBefore, snapshotProtos())) {
      reason = 'prototype_pollution';
      error = 'Your code modified a built-in prototype (Array.prototype, Object.prototype, etc.). This is not allowed.';
    }
  } catch (err) {
    error = err.message || String(err);
    reason = err.code === 'ERR_SCRIPT_EXECUTION_TIMEOUT' ? 'timeout' : 'runtime_error';
    result = undefined;
  }

  const passed = reason === 'ok' && deepEqual(result, expectedClone);

  return {
    passed,
    reason,
    actual: result,
    expected: expectedClone,
    input: inputClone,
    error,
    timeMs: Date.now() - t0,
    logs,
    actualStr: safeStr(result),
    expectedStr: safeStr(expectedClone),
    inputStr: safeStr(inputClone),
  };
}

function runAllTestCases(userCode, testCases, options = {}) {
  const timeoutMs = options.timeoutMs || DEFAULT_TIMEOUT_MS;

  if (typeof userCode !== 'string') {
    return { allPassed: false, syntaxError: 'Code must be a string.', results: [], totalTimeMs: 0 };
  }
  if (userCode.length > MAX_CODE_LENGTH) {
    return { allPassed: false, syntaxError: `Code exceeds maximum length (${MAX_CODE_LENGTH} chars).`, results: [], totalTimeMs: 0 };
  }

  const syn = validateSyntax(userCode);
  if (!syn.valid) {
    return { allPassed: false, syntaxError: syn.error, results: [], totalTimeMs: 0 };
  }

  const t0 = Date.now();
  const results = [];

  for (let i = 0; i < testCases.length; i++) {
    const res = runOneTestCase(userCode, testCases[i], timeoutMs);
    results.push({ testNum: i + 1, ...res });

    if (res.reason === 'timeout') {
      for (let j = i + 1; j < testCases.length; j++) {
        results.push(skippedResult(j + 1, testCases[j]));
      }
      break;
    }
  }

  return {
    allPassed: results.every(r => r.passed),
    results,
    totalTimeMs: Date.now() - t0,
    syntaxError: null,
  };
}

function skippedResult(testNum, testCase) {
  const input = testCase.stdin ?? testCase.input;
  return {
    testNum,
    passed: false,
    reason: 'skipped',
    actual: undefined,
    expected: deepClone(testCase.expected),
    input: deepClone(input),
    error: 'Skipped — previous test timed out.',
    timeMs: 0,
    logs: [],
    actualStr: 'N/A',
    expectedStr: safeStr(testCase.expected),
    inputStr: safeStr(input),
  };
}

function buildInputPayload(challengeId, testCase) {
  if (testCase.stdin != null) return String(testCase.stdin).replace(/\r/g, '') + '\n';
  const input = testCase.input;
  switch (challengeId) {
    case 1:
    case 3: {
      const arr = Array.isArray(input) ? input : [];
      return `${arr.length}\n${arr.join(' ')}\n`;
    }
    case 2:
    case 4:
      return `${String(input ?? '')}\n`;
    case 5:
      return `${Number(input || 0)}\n`;
    case 6: {
      const arr = Array.isArray(input?.arr) ? input.arr : [];
      return `${arr.length}\n${arr.join(' ')}\n${Number(input?.target || 0)}\n`;
    }
    default:
      throw new Error(`Unsupported challenge id: ${challengeId}`);
  }
}

function parseExecutionOutput(stdout, stderr) {
  const logs = [];
  let resultText = null;
  String(stdout || '').replace(/\r/g, '').split('\n').forEach(line => {
    if (!line) return;
    if (line.startsWith(RESULT_MARKER)) resultText = line.slice(RESULT_MARKER.length);
    else if (logs.join('').length < MAX_LOG_CHARS) logs.push(line);
  });
  String(stderr || '').replace(/\r/g, '').split('\n').forEach(line => {
    if (!line) return;
    if (logs.join('').length < MAX_LOG_CHARS) logs.push('[stderr] ' + line);
  });
  if (resultText == null) return { ok: false, logs, error: 'Program did not return a parseable result.' };
  try {
    return { ok: true, logs, actual: JSON.parse(resultText) };
  } catch (err) {
    return { ok: false, logs, error: `Program returned invalid JSON output: ${err.message}` };
  }
}

function trimCompileError(text) {
  return String(text || '').trim().split('\n').slice(0, 12).join('\n') || 'Compilation failed.';
}

async function runProcess(command, args, options = {}) {
  const {
    cwd,
    input = '',
    timeoutMs = DEFAULT_TIMEOUT_MS,
  } = options;

  return await new Promise((resolve, reject) => {
    const tempRoot = cwd || os.tmpdir();
    const child = spawn(command, args, {
      cwd,
      env: {
        PATH: process.env.PATH || '',
        TMPDIR: tempRoot,
        TMP: tempRoot,
        TEMP: tempRoot,
      },
      stdio: 'pipe',
    });

    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, timeoutMs);

    child.stdout.on('data', d => { stdout += d.toString(); });
    child.stderr.on('data', d => { stderr += d.toString(); });
    child.on('error', err => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', code => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr, timedOut });
    });

    if (input) child.stdin.write(input);
    child.stdin.end();
  });
}

function pythonHarness(userCode, challengeId) {
  return `
import json
import sys

${userCode}

if 'solution' not in globals() or not callable(solution):
    raise NameError('No function named "solution" found. Define def solution(...):')

lines = sys.stdin.read().splitlines()
idx = 0
def next_line():
    global idx
    line = lines[idx] if idx < len(lines) else ''
    idx += 1
    return line

challenge_id = ${challengeId}
if challenge_id in (1, 3):
    next_line()
    arr = [int(x) for x in next_line().split()] if len(lines) > 1 and lines[1].strip() else []
    result = solution(arr)
elif challenge_id in (2, 4):
    result = solution(next_line())
elif challenge_id == 5:
    result = solution(int(next_line() or 0))
elif challenge_id == 6:
    next_line()
    arr = [int(x) for x in next_line().split()] if len(lines) > 1 and lines[1].strip() else []
    target = int(next_line() or 0)
    result = solution(arr, target)
else:
    raise ValueError('Unsupported challenge id')

print('${RESULT_MARKER}' + json.dumps(result))
`;
}

function cHarness(userCode, challengeId) {
  const runner = {
    1: `
int main(void) {
  int n = 0;
  if (scanf("%d", &n) != 1) return 1;
  int arr[1024];
  for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
  printf("${RESULT_MARKER}%d\\n", solution(arr, n));
  return 0;
}
`,
    2: `
int main(void) {
  char input[4096];
  if (!fgets(input, sizeof(input), stdin)) input[0] = '\\0';
  input[strcspn(input, "\\n")] = '\\0';
  char output[4096] = {0};
  solution(input, output);
  print_json_string(output);
  return 0;
}
`,
    3: `
int main(void) {
  int n = 0;
  if (scanf("%d", &n) != 1) return 1;
  int arr[1024];
  for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
  printf("${RESULT_MARKER}%d\\n", solution(arr, n));
  return 0;
}
`,
    4: `
int main(void) {
  char input[4096];
  if (!fgets(input, sizeof(input), stdin)) input[0] = '\\0';
  input[strcspn(input, "\\n")] = '\\0';
  printf("${RESULT_MARKER}%s\\n", solution(input) ? "true" : "false");
  return 0;
}
`,
    5: `
int main(void) {
  int n = 0;
  if (scanf("%d", &n) != 1) return 1;
  char output[1024][32];
  int out_len = 0;
  solution(n, output, &out_len);
  print_json_string_array(output, out_len);
  return 0;
}
`,
    6: `
int main(void) {
  int n = 0;
  if (scanf("%d", &n) != 1) return 1;
  int arr[1024];
  for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
  int target = 0;
  scanf("%d", &target);
  printf("${RESULT_MARKER}%d\\n", solution(arr, n, target));
  return 0;
}
`,
  }[challengeId];

  return `
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void print_json_string(const char *s) {
  printf("${RESULT_MARKER}\\"");
  for (const char *p = s; *p; ++p) {
    if (*p == '\\\\' || *p == '"') printf("\\\\%c", *p);
    else if (*p == '\\n') printf("\\\\n");
    else printf("%c", *p);
  }
  printf("\\"\\n");
}

static void print_json_string_array(char arr[][32], int len) {
  printf("${RESULT_MARKER}[");
  for (int i = 0; i < len; i++) {
    if (i) printf(",");
    printf("\\"");
    for (const char *p = arr[i]; *p; ++p) {
      if (*p == '\\\\' || *p == '"') printf("\\\\%c", *p);
      else if (*p == '\\n') printf("\\\\n");
      else printf("%c", *p);
    }
    printf("\\"");
  }
  printf("]\\n");
}

${userCode}

${runner}
`;
}

function cppHarness(userCode, challengeId) {
  const runner = {
    1: `
int main() {
  int n = 0;
  if (!(std::cin >> n)) return 1;
  std::vector<int> arr(n);
  for (int i = 0; i < n; ++i) std::cin >> arr[i];
  std::cout << "${RESULT_MARKER}" << solution(arr) << "\\n";
  return 0;
}
`,
    2: `
int main() {
  std::string input;
  std::getline(std::cin, input);
  print_json_string(solution(input));
  return 0;
}
`,
    3: `
int main() {
  int n = 0;
  if (!(std::cin >> n)) return 1;
  std::vector<int> arr(n);
  for (int i = 0; i < n; ++i) std::cin >> arr[i];
  std::cout << "${RESULT_MARKER}" << solution(arr) << "\\n";
  return 0;
}
`,
    4: `
int main() {
  std::string input;
  std::getline(std::cin, input);
  std::cout << "${RESULT_MARKER}" << (solution(input) ? "true" : "false") << "\\n";
  return 0;
}
`,
    5: `
int main() {
  int n = 0;
  if (!(std::cin >> n)) return 1;
  print_json_string_vector(solution(n));
  return 0;
}
`,
    6: `
int main() {
  int n = 0;
  if (!(std::cin >> n)) return 1;
  std::vector<int> arr(n);
  for (int i = 0; i < n; ++i) std::cin >> arr[i];
  int target = 0;
  std::cin >> target;
  std::cout << "${RESULT_MARKER}" << solution(arr, target) << "\\n";
  return 0;
}
`,
  }[challengeId];

  return `
#include <iostream>
#include <string>
#include <vector>

static std::string escape_json(const std::string &value) {
  std::string out;
  for (char c : value) {
    if (c == '\\\\' || c == '"') { out.push_back('\\\\'); out.push_back(c); }
    else if (c == '\\n') out += "\\\\n";
    else out.push_back(c);
  }
  return out;
}

static void print_json_string(const std::string &value) {
  std::cout << "${RESULT_MARKER}\\"" << escape_json(value) << "\\"\\n";
}

static void print_json_string_vector(const std::vector<std::string> &items) {
  std::cout << "${RESULT_MARKER}[";
  for (size_t i = 0; i < items.size(); ++i) {
    if (i) std::cout << ",";
    std::cout << "\\"" << escape_json(items[i]) << "\\"";
  }
  std::cout << "]\\n";
}

${userCode}

${runner}
`;
}

function createSource(language, userCode, challengeId) {
  switch (language) {
    case 'python': return pythonHarness(userCode, challengeId);
    case 'c': return cHarness(userCode, challengeId);
    case 'cpp': return cppHarness(userCode, challengeId);
    default: throw new Error(`Unsupported language: ${language}`);
  }
}

async function prepareExecutable(language, userCode, challengeId, options = {}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), `code-combat-${language}-`));
  const ext = language === 'python' ? 'py' : language === 'c' ? 'c' : 'cpp';
  const sourcePath = path.join(dir, `solution.${ext}`);
  const binaryPath = path.join(dir, 'solution.bin');
  await fs.writeFile(sourcePath, options.stdio ? userCode : createSource(language, userCode, challengeId), 'utf8');

  if (language === 'python') {
    const check = await runProcess('python3', ['-m', 'py_compile', sourcePath], { cwd: dir, timeoutMs: COMPILE_TIMEOUT_MS });
    if (check.timedOut) {
      return { dir, syntaxError: 'Python syntax validation timed out.' };
    }
    if (check.code !== 0) {
      return { dir, syntaxError: trimCompileError(check.stderr || check.stdout) };
    }
    return { dir, command: 'python3', args: [sourcePath] };
  }

  const compiler = language === 'c' ? 'gcc' : 'g++';
  const args = language === 'c'
    ? [sourcePath, '-std=c11', '-O2', '-o', binaryPath]
    : [sourcePath, '-std=c++17', '-O2', '-o', binaryPath];
  const compile = await runProcess(compiler, args, { cwd: dir, timeoutMs: COMPILE_TIMEOUT_MS });
  if (compile.timedOut) {
    return { dir, syntaxError: `${language.toUpperCase()} compilation timed out.` };
  }
  if (compile.code !== 0) {
    return { dir, syntaxError: trimCompileError(compile.stderr || compile.stdout) };
  }
  return { dir, command: binaryPath, args: [] };
}

async function cleanupDir(dir) {
  if (!dir) return;
  await fs.rm(dir, { recursive: true, force: true });
}

async function runExternalLanguage(language, userCode, testCases, options = {}) {
  const timeoutMs = options.timeoutMs || DEFAULT_TIMEOUT_MS;
  const challengeId = options.challengeId;

  if (typeof userCode !== 'string') {
    return { allPassed: false, syntaxError: 'Code must be a string.', results: [], totalTimeMs: 0 };
  }
  if (userCode.length > MAX_CODE_LENGTH) {
    return { allPassed: false, syntaxError: `Code exceeds maximum length (${MAX_CODE_LENGTH} chars).`, results: [], totalTimeMs: 0 };
  }
  if (!challengeId) {
    return { allPassed: false, syntaxError: 'Challenge id is required for non-JavaScript evaluation.', results: [], totalTimeMs: 0 };
  }

  const t0 = Date.now();
  const results = [];
  const prepared = await prepareExecutable(language, userCode, challengeId, options);
  try {
    if (prepared.syntaxError) {
      return { allPassed: false, syntaxError: prepared.syntaxError, results: [], totalTimeMs: 0 };
    }

    for (let i = 0; i < testCases.length; i++) {
      const testCase = testCases[i];
      const startedAt = Date.now();
      const proc = await runProcess(prepared.command, prepared.args, {
        cwd: prepared.dir,
        input: buildInputPayload(challengeId, testCase),
        timeoutMs,
      });

      if (proc.timedOut) {
        const input = options.stdio ? testCase.stdin : testCase.input;
        results.push({
          testNum: i + 1,
          passed: false,
          reason: 'timeout',
          actual: undefined,
          expected: deepClone(testCase.expected),
          input: deepClone(input),
          error: 'Execution timed out.',
          timeMs: Date.now() - startedAt,
          logs: [],
          actualStr: 'undefined',
          expectedStr: safeStr(testCase.expected),
          inputStr: safeStr(input),
        });
        for (let j = i + 1; j < testCases.length; j++) results.push(skippedResult(j + 1, testCases[j]));
        break;
      }

      const parsed = options.stdio ? null : parseExecutionOutput(proc.stdout, proc.stderr);
      const input = options.stdio ? testCase.stdin : testCase.input;
      const actual = options.stdio ? normalizeTextOutput(proc.stdout) : parsed.ok ? parsed.actual : undefined;
      const expected = options.stdio ? normalizeTextOutput(testCase.expected) : deepClone(testCase.expected);
      const reason = proc.code !== 0 ? 'runtime_error' : options.stdio ? 'ok' : parsed.ok ? 'ok' : 'runtime_error';
      const error = proc.code !== 0
        ? trimCompileError(proc.stderr || proc.stdout)
        : options.stdio || parsed.ok ? null : parsed.error;
      const passed = reason === 'ok' && (options.stdio ? actual === expected : deepEqual(actual, expected));

      results.push({
        testNum: i + 1,
        passed,
        reason,
        actual,
        expected,
        input: deepClone(input),
        error,
        timeMs: Date.now() - startedAt,
        logs: options.stdio ? [] : parsed.logs,
        actualStr: safeStr(actual),
        expectedStr: safeStr(expected),
        inputStr: safeStr(input),
      });
    }

    return {
      allPassed: results.length > 0 && results.every(r => r.passed),
      syntaxError: null,
      results,
      totalTimeMs: Date.now() - t0,
    };
  } finally {
    await cleanupDir(prepared.dir);
  }
}

async function runPython(userCode, testCases, options = {}) {
  return await runExternalLanguage('python', userCode, testCases, options);
}

async function runC(userCode, testCases, options = {}) {
  return await runExternalLanguage('c', userCode, testCases, options);
}

async function runCpp(userCode, testCases, options = {}) {
  return await runExternalLanguage('cpp', userCode, testCases, options);
}

async function runJavaScriptStdio(userCode, testCases, options = {}) {
  const timeoutMs = options.timeoutMs || DEFAULT_TIMEOUT_MS;
  if (typeof userCode !== 'string') {
    return { allPassed: false, syntaxError: 'Code must be a string.', results: [], totalTimeMs: 0 };
  }
  if (userCode.length > MAX_CODE_LENGTH) {
    return { allPassed: false, syntaxError: `Code exceeds maximum length (${MAX_CODE_LENGTH} chars).`, results: [], totalTimeMs: 0 };
  }
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'code-combat-js-'));
  const sourcePath = path.join(dir, 'solution.js');
  await fs.writeFile(sourcePath, userCode, 'utf8');
  const t0 = Date.now();
  const results = [];
  try {
    for (let i = 0; i < testCases.length; i++) {
      const testCase = testCases[i];
      const startedAt = Date.now();
      const proc = await runProcess(process.execPath, [sourcePath], {
        cwd: dir,
        input: buildInputPayload(options.challengeId, testCase),
        timeoutMs,
      });
      const actual = normalizeTextOutput(proc.stdout);
      const expected = normalizeTextOutput(testCase.expected);
      const reason = proc.timedOut ? 'timeout' : proc.code !== 0 ? 'runtime_error' : 'ok';
      const error = proc.timedOut ? 'Execution timed out.' : proc.code !== 0 ? trimCompileError(proc.stderr || proc.stdout) : null;
      const passed = reason === 'ok' && actual === expected;
      results.push({
        testNum: i + 1,
        passed,
        reason,
        actual,
        expected,
        input: testCase.stdin,
        error,
        timeMs: Date.now() - startedAt,
        logs: [],
        actualStr: safeStr(actual),
        expectedStr: safeStr(expected),
        inputStr: safeStr(testCase.stdin),
      });
      if (proc.timedOut) {
        for (let j = i + 1; j < testCases.length; j++) results.push(skippedResult(j + 1, testCases[j]));
        break;
      }
    }
    return {
      allPassed: results.length > 0 && results.every(r => r.passed),
      syntaxError: null,
      results,
      totalTimeMs: Date.now() - t0,
    };
  } finally {
    await cleanupDir(dir);
  }
}

module.exports = {
  runAllTestCases,
  runOneTestCase,
  runPython,
  runC,
  runCpp,
  runJavaScriptStdio,
  deepClone,
  deepEqual,
  safeStr,
  validateSyntax,
};
