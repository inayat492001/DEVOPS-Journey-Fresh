/**
 * server.js — CODE COMBAT  v2.0
 * ─────────────────────────────────────────────────────────────
 * Changes from v1:
 *  • All code evaluation moved server-side via evaluator.js
 *  • EvaluationQueue prevents concurrent submissions per socket
 *  • RateLimiter caps 5 submissions / 10 s per socket
 *  • Challenge expected values never sent to client
 *  • Structured JSON logging with submitId correlation
 *  • /health and /api/challenges REST endpoints
 *  • CORS_ORIGIN env var — restrict in production
 */

'use strict';

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const path       = require('path');
const crypto     = require('crypto');

const { runAllTestCases, runPython, runC, runCpp, runJavaScriptStdio } = require('./evaluator');

// ─── Config ──────────────────────────────────────────────────
const PORT        = parseInt(process.env.PORT, 10) || 3000;
const NODE_ENV    = process.env.NODE_ENV || 'development';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';
const MAX_PLAYERS = 5;
const PLAYER_KEYS = Array.from({ length: MAX_PLAYERS }, (_, i) => `p${i + 1}`);

// ─── Structured Logger ───────────────────────────────────────
function log(level, event, data = {}) {
  console[level === 'error' ? 'error' : 'log'](
    JSON.stringify({ ts: new Date().toISOString(), level, event, ...data })
  );
}

// ─── Challenge Database ──────────────────────────────────────
// Expected values live on the server only — never sent to clients
const TEMPLATE_HINTS = {
  1: 'Input: A B',
  2: 'Input: three integers',
  3: 'Input: N',
  4: 'Input: N',
  5: 'Input: one string S',
  6: 'Input: one lowercase string S',
  7: 'Input: N',
  8: 'Input: one string S',
  9: 'Input: A B',
  10: 'Input: N',
  11: 'Input: N, where F(0)=0 and F(1)=1',
  12: 'Input: N followed by N integers',
  13: 'Input: N followed by N integers',
  14: 'Input: N followed by N integers',
  15: 'Input: N followed by N integers; print the second largest distinct value',
  16: 'Input: year Y',
  17: 'Input: one string S; swap the case of each letter',
  18: 'Input: integer N; print the sum of its digits',
  19: 'Input: N; print the multiplication table from 1 to 10',
  20: 'Input: A B; compute A^B modulo 1000000007',
  21: 'Input: N target, then N integers; print 1-based indices',
  22: 'Input: N X, then sorted array of N integers; print 1-based index or -1',
  23: 'Input: N M, then two sorted arrays; print the merged sorted array',
  24: 'Input: one sentence; print the longest word, first one if tied',
  25: 'Input: two strings on separate lines; print YES if they are anagrams',
  26: 'Input: N followed by N integers; print distinct count',
  27: 'Input: R C, then R rows of a matrix; print the transpose',
  28: 'Input: bracket string containing (){}[]; print YES if balanced',
  29: 'Input: N K, then N integers; print max sum of any K consecutive elements',
  30: 'Input: N followed by N integers; sort by frequency descending, value ascending',
  31: 'Input: N followed by N integers; print LIS length',
  32: 'Input: N M, then M edges u v w; print shortest path from 1 to N or -1',
  33: 'Input: two strings A and B on separate lines; print edit distance',
  34: 'Input: N; print the number of N-Queens solutions',
  35: 'Input: N Q, array, then Q operations; type 1 updates, type 2 range sum queries',
};

function makeTemplates(id) {
  const hint = TEMPLATE_HINTS[id] || 'Read stdin and print the required output.';
  return {
    javascript: makeJavaScriptTemplate(id, hint),
    python    : makePythonTemplate(id, hint),
    c         : makeCTemplate(id, hint),
    cpp       : makeCppTemplate(id, hint),
  };
}

const JS_STARTERS = {
  1: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet A = Number(input[0]);\nlet B = Number(input[1]);",
  2: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet A = Number(input[0]);\nlet B = Number(input[1]);\nlet C = Number(input[2]);",
  3: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  4: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  5: "const S = require('fs').readFileSync(0, 'utf8').trim();",
  6: "const S = require('fs').readFileSync(0, 'utf8').trim();",
  7: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  8: "const S = require('fs').readFileSync(0, 'utf8').trim();",
  9: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet A = Number(input[0]);\nlet B = Number(input[1]);",
  10: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  11: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  12: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet N = Number(input[0]);\nlet arr = input.slice(1).map(Number);",
  13: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet N = Number(input[0]);\nlet arr = input.slice(1).map(Number);",
  14: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet N = Number(input[0]);\nlet arr = input.slice(1).map(Number);",
  15: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet N = Number(input[0]);\nlet arr = input.slice(1).map(Number);",
  16: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet year = Number(input);",
  17: "const S = require('fs').readFileSync(0, 'utf8').trim();",
  18: "const N = require('fs').readFileSync(0, 'utf8').trim();",
  19: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  20: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/);\n\nlet A = Number(input[0]);\nlet B = Number(input[1]);",
  21: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet target = input[1];\nlet arr = input.slice(2);",
  22: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet X = input[1];\nlet arr = input.slice(2);",
  23: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet [N, M] = lines[0].split(/\\s+/).map(Number);\nlet first = lines[1].split(/\\s+/).map(Number);\nlet second = lines[2].split(/\\s+/).map(Number);",
  24: "const sentence = require('fs').readFileSync(0, 'utf8').trim();",
  25: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet A = lines[0];\nlet B = lines[1];",
  26: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet arr = input.slice(1);",
  27: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet [R, C] = lines[0].split(/\\s+/).map(Number);\nlet matrix = lines.slice(1).map(line => line.split(/\\s+/).map(Number));",
  28: "const brackets = require('fs').readFileSync(0, 'utf8').trim();",
  29: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet K = input[1];\nlet arr = input.slice(2);",
  30: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet arr = input.slice(1);",
  31: "const input = require('fs').readFileSync(0, 'utf8').trim().split(/\\s+/).map(Number);\n\nlet N = input[0];\nlet arr = input.slice(1);",
  32: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet [N, M] = lines[0].split(/\\s+/).map(Number);\nlet edges = lines.slice(1).map(line => line.split(/\\s+/).map(Number));",
  33: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet A = lines[0];\nlet B = lines[1];",
  34: "const input = require('fs').readFileSync(0, 'utf8').trim();\n\nlet N = Number(input);",
  35: "const lines = require('fs').readFileSync(0, 'utf8').trim().split(/\\n/);\n\nlet [N, Q] = lines[0].split(/\\s+/).map(Number);\nlet arr = lines[1].split(/\\s+/).map(Number);\nlet operations = lines.slice(2).map(line => line.split(/\\s+/).map(Number));",
};

const PY_STARTERS = {
  1: "import sys\n\ndata = sys.stdin.read().split()\n\nA = int(data[0])\nB = int(data[1])",
  2: "import sys\n\ndata = sys.stdin.read().split()\n\nA = int(data[0])\nB = int(data[1])\nC = int(data[2])",
  3: "import sys\n\nN = int(sys.stdin.read().strip())",
  4: "import sys\n\nN = int(sys.stdin.read().strip())",
  5: "import sys\n\nS = sys.stdin.read().strip()",
  6: "import sys\n\nS = sys.stdin.read().strip()",
  7: "import sys\n\nN = int(sys.stdin.read().strip())",
  8: "import sys\n\nS = sys.stdin.read().strip()",
  9: "import sys\n\ndata = sys.stdin.read().split()\n\nA = int(data[0])\nB = int(data[1])",
  10: "import sys\n\nN = int(sys.stdin.read().strip())",
  11: "import sys\n\nN = int(sys.stdin.read().strip())",
  12: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  13: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  14: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  15: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  16: "import sys\n\nyear = int(sys.stdin.read().strip())",
  17: "import sys\n\nS = sys.stdin.read().strip()",
  18: "import sys\n\nN = sys.stdin.read().strip()",
  19: "import sys\n\nN = int(sys.stdin.read().strip())",
  20: "import sys\n\ndata = sys.stdin.read().split()\n\nA = int(data[0])\nB = int(data[1])",
  21: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\ntarget = int(data[1])\narr = list(map(int, data[2:]))",
  22: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\nX = int(data[1])\narr = list(map(int, data[2:]))",
  23: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nN, M = map(int, lines[0].split())\nfirst = list(map(int, lines[1].split()))\nsecond = list(map(int, lines[2].split()))",
  24: "import sys\n\nsentence = sys.stdin.read().strip()",
  25: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nA = lines[0]\nB = lines[1]",
  26: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  27: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nR, C = map(int, lines[0].split())\nmatrix = [list(map(int, line.split())) for line in lines[1:]]",
  28: "import sys\n\nbrackets = sys.stdin.read().strip()",
  29: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\nK = int(data[1])\narr = list(map(int, data[2:]))",
  30: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  31: "import sys\n\ndata = sys.stdin.read().split()\n\nN = int(data[0])\narr = list(map(int, data[1:]))",
  32: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nN, M = map(int, lines[0].split())\nedges = [tuple(map(int, line.split())) for line in lines[1:]]",
  33: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nA = lines[0]\nB = lines[1]",
  34: "import sys\n\nN = int(sys.stdin.read().strip())",
  35: "import sys\n\nlines = sys.stdin.read().strip().splitlines()\nN, Q = map(int, lines[0].split())\narr = list(map(int, lines[1].split()))\noperations = [tuple(map(int, line.split())) for line in lines[2:]]",
};

const C_STARTERS = {
  1: '    long long A, B;\n    scanf("%lld %lld", &A, &B);',
  2: '    long long A, B, C;\n    scanf("%lld %lld %lld", &A, &B, &C);',
  3: '    long long N;\n    scanf("%lld", &N);',
  4: '    int N;\n    scanf("%d", &N);',
  5: '    char S[1005];\n    scanf("%1000s", S);',
  6: '    char S[100005];\n    scanf("%100000s", S);',
  7: '    long long N;\n    scanf("%lld", &N);',
  8: '    char S[1005];\n    scanf("%1000s", S);',
  9: '    long long A, B;\n    scanf("%lld %lld", &A, &B);',
  10: '    long long N;\n    scanf("%lld", &N);',
  11: '    int N;\n    scanf("%d", &N);',
  12: '    int N;\n    long long arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);',
  13: '    int N;\n    long long arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);',
  14: '    int N;\n    long long arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);',
  15: '    int N;\n    long long arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);',
  16: '    int year;\n    scanf("%d", &year);',
  17: '    char S[1005];\n    scanf("%1000s", S);',
  18: '    char N[1005];\n    scanf("%1000s", N);',
  19: '    int N;\n    scanf("%d", &N);',
  20: '    long long A, B;\n    scanf("%lld %lld", &A, &B);',
  21: '    int N, target;\n    int arr[100005];\n    scanf("%d %d", &N, &target);\n    for (int i = 0; i < N; i++) scanf("%d", &arr[i]);',
  22: '    int N, X;\n    int arr[100005];\n    scanf("%d %d", &N, &X);\n    for (int i = 0; i < N; i++) scanf("%d", &arr[i]);',
  23: '    int N, M;\n    int first[100005], second[100005];\n    scanf("%d %d", &N, &M);\n    for (int i = 0; i < N; i++) scanf("%d", &first[i]);\n    for (int i = 0; i < M; i++) scanf("%d", &second[i]);',
  24: '    char sentence[4096];\n    fgets(sentence, sizeof(sentence), stdin);',
  25: '    char A[1005], B[1005];\n    scanf("%1000s %1000s", A, B);',
  26: '    int N;\n    int arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%d", &arr[i]);',
  27: '    int R, C;\n    int matrix[105][105];\n    scanf("%d %d", &R, &C);\n    for (int i = 0; i < R; i++) {\n        for (int j = 0; j < C; j++) scanf("%d", &matrix[i][j]);\n    }',
  28: '    char brackets[100005];\n    scanf("%100000s", brackets);',
  29: '    int N, K;\n    long long arr[100005];\n    scanf("%d %d", &N, &K);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);',
  30: '    int N;\n    int arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%d", &arr[i]);',
  31: '    int N;\n    int arr[100005];\n    scanf("%d", &N);\n    for (int i = 0; i < N; i++) scanf("%d", &arr[i]);',
  32: '    int N, M;\n    int U[100005], V[100005], W[100005];\n    scanf("%d %d", &N, &M);\n    for (int i = 0; i < M; i++) scanf("%d %d %d", &U[i], &V[i], &W[i]);',
  33: '    char A[1005], B[1005];\n    scanf("%1000s %1000s", A, B);',
  34: '    int N;\n    scanf("%d", &N);',
  35: '    int N, Q;\n    long long arr[100005];\n    int type[100005], L[100005], R[100005];\n    scanf("%d %d", &N, &Q);\n    for (int i = 0; i < N; i++) scanf("%lld", &arr[i]);\n    for (int i = 0; i < Q; i++) scanf("%d %d %d", &type[i], &L[i], &R[i]);',
};

const CPP_STARTERS = {
  1: '    long long A, B;\n    cin >> A >> B;',
  2: '    long long A, B, C;\n    cin >> A >> B >> C;',
  3: '    long long N;\n    cin >> N;',
  4: '    int N;\n    cin >> N;',
  5: '    string S;\n    cin >> S;',
  6: '    string S;\n    cin >> S;',
  7: '    long long N;\n    cin >> N;',
  8: '    string S;\n    cin >> S;',
  9: '    long long A, B;\n    cin >> A >> B;',
  10: '    long long N;\n    cin >> N;',
  11: '    int N;\n    cin >> N;',
  12: '    int N;\n    cin >> N;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  13: '    int N;\n    cin >> N;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  14: '    int N;\n    cin >> N;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  15: '    int N;\n    cin >> N;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  16: '    int year;\n    cin >> year;',
  17: '    string S;\n    cin >> S;',
  18: '    string N;\n    cin >> N;',
  19: '    int N;\n    cin >> N;',
  20: '    long long A, B;\n    cin >> A >> B;',
  21: '    int N, target;\n    cin >> N >> target;\n    vector<int> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  22: '    int N, X;\n    cin >> N >> X;\n    vector<int> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  23: '    int N, M;\n    cin >> N >> M;\n    vector<int> first(N), second(M);\n    for (int i = 0; i < N; i++) cin >> first[i];\n    for (int i = 0; i < M; i++) cin >> second[i];',
  24: '    string sentence;\n    getline(cin >> ws, sentence);',
  25: '    string A, B;\n    cin >> A >> B;',
  26: '    int N;\n    cin >> N;\n    vector<int> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  27: '    int R, C;\n    cin >> R >> C;\n    vector<vector<int>> matrix(R, vector<int>(C));\n    for (int i = 0; i < R; i++) {\n        for (int j = 0; j < C; j++) cin >> matrix[i][j];\n    }',
  28: '    string brackets;\n    cin >> brackets;',
  29: '    int N, K;\n    cin >> N >> K;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  30: '    int N;\n    cin >> N;\n    vector<int> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  31: '    int N;\n    cin >> N;\n    vector<int> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];',
  32: '    int N, M;\n    cin >> N >> M;\n    vector<vector<int>> edges(M, vector<int>(3));\n    for (int i = 0; i < M; i++) cin >> edges[i][0] >> edges[i][1] >> edges[i][2];',
  33: '    string A, B;\n    cin >> A >> B;',
  34: '    int N;\n    cin >> N;',
  35: '    int N, Q;\n    cin >> N >> Q;\n    vector<long long> arr(N);\n    for (int i = 0; i < N; i++) cin >> arr[i];\n    vector<vector<int>> operations(Q, vector<int>(3));\n    for (int i = 0; i < Q; i++) cin >> operations[i][0] >> operations[i][1] >> operations[i][2];',
};

function makeJavaScriptTemplate(id, hint) {
  return `${JS_STARTERS[id] || "const input = require('fs').readFileSync(0, 'utf8').trim();"}\n\n// ${hint}\n// Write your code here\n`;
}

function makePythonTemplate(id, hint) {
  return `${PY_STARTERS[id] || 'import sys\n\ndata = sys.stdin.read().strip()'}\n\n# ${hint}\n# Write your code here\n`;
}

function makeCTemplate(id, hint) {
  return `#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n\nint main(void) {\n${C_STARTERS[id] || `    // ${hint}`}\n\n    // Write your code here\n    return 0;\n}\n`;
}

function makeCppTemplate(id, hint) {
  return `#include <iostream>\n#include <string>\n#include <vector>\nusing namespace std;\n\nint main() {\n    ios::sync_with_stdio(false);\n    cin.tie(nullptr);\n\n${CPP_STARTERS[id] || `    // ${hint}`}\n\n    // Write your code here\n    return 0;\n}\n`;
}

const CHALLENGES = [
  {
    id: 1, title: "Sum of Two Numbers", difficulty: "easy", timeLimit: 300,
    desc: "Given two integers A and B, print their sum.",
    ioMode: 'stdio',
    template: makeTemplates(1),
    testCases: [
      { stdin: "3 5", expected: "8" },
      { stdin: "-2 7", expected: "5" },
      { stdin: "0 0", expected: "0" },
    ],
  },
  {
    id: 2, title: "Maximum of Three", difficulty: "easy", timeLimit: 300,
    desc: "Given three integers, print the largest.",
    ioMode: 'stdio',
    template: makeTemplates(2),
    testCases: [
      { stdin: "1 2 3", expected: "3" },
      { stdin: "9 4 7", expected: "9" },
      { stdin: "-1 -2 -3", expected: "-1" },
    ],
  },
  {
    id: 3, title: "Even or Odd", difficulty: "easy", timeLimit: 300,
    desc: "Given an integer N, print 'Even' or 'Odd'.",
    ioMode: 'stdio',
    template: makeTemplates(3),
    testCases: [
      { stdin: "4", expected: "Even" },
      { stdin: "7", expected: "Odd" },
      { stdin: "0", expected: "Even" },
    ],
  },
  {
    id: 4, title: "Factorial", difficulty: "easy", timeLimit: 300,
    desc: "Compute N! for non-negative integer N.",
    ioMode: 'stdio',
    template: makeTemplates(4),
    testCases: [
      { stdin: "5", expected: "120" },
      { stdin: "0", expected: "1" },
      { stdin: "10", expected: "3628800" },
    ],
  },
  {
    id: 5, title: "Reverse a String", difficulty: "easy", timeLimit: 300,
    desc: "Reverse the given string.",
    ioMode: 'stdio',
    template: makeTemplates(5),
    testCases: [
      { stdin: "hello", expected: "olleh" },
      { stdin: "abc", expected: "cba" },
      { stdin: "a", expected: "a" },
    ],
  },
  {
    id: 6, title: "Count Vowels", difficulty: "easy", timeLimit: 300,
    desc: "Count vowels (aeiou) in a lowercase string.",
    ioMode: 'stdio',
    template: makeTemplates(6),
    testCases: [
      { stdin: "hello", expected: "2" },
      { stdin: "xyz", expected: "0" },
      { stdin: "aeiou", expected: "5" },
    ],
  },
  {
    id: 7, title: "Sum 1 to N", difficulty: "easy", timeLimit: 300,
    desc: "Print sum of integers from 1 to N.",
    ioMode: 'stdio',
    template: makeTemplates(7),
    testCases: [
      { stdin: "5", expected: "15" },
      { stdin: "10", expected: "55" },
      { stdin: "1", expected: "1" },
    ],
  },
  {
    id: 8, title: "Palindrome Check", difficulty: "easy", timeLimit: 300,
    desc: "Check if string is a palindrome. Print 'YES' or 'NO'.",
    ioMode: 'stdio',
    template: makeTemplates(8),
    testCases: [
      { stdin: "racecar", expected: "YES" },
      { stdin: "hello", expected: "NO" },
      { stdin: "a", expected: "YES" },
    ],
  },
  {
    id: 9, title: "GCD", difficulty: "easy", timeLimit: 300,
    desc: "Compute GCD of A and B.",
    ioMode: 'stdio',
    template: makeTemplates(9),
    testCases: [
      { stdin: "12 18", expected: "6" },
      { stdin: "7 5", expected: "1" },
      { stdin: "100 25", expected: "25" },
    ],
  },
  {
    id: 10, title: "Prime Check", difficulty: "easy", timeLimit: 300,
    desc: "Check if N is prime. Print 'YES' or 'NO'.",
    ioMode: 'stdio',
    template: makeTemplates(10),
    testCases: [
      { stdin: "7", expected: "YES" },
      { stdin: "10", expected: "NO" },
      { stdin: "2", expected: "YES" },
    ],
  },
  {
    id: 11, title: "Fibonacci Nth", difficulty: "easy", timeLimit: 300,
    desc: "Print the Nth Fibonacci number (F(0)=0, F(1)=1).",
    ioMode: 'stdio',
    template: makeTemplates(11),
    testCases: [
      { stdin: "5", expected: "5" },
      { stdin: "0", expected: "0" },
      { stdin: "10", expected: "55" },
    ],
  },
  {
    id: 12, title: "Array Sum", difficulty: "easy", timeLimit: 300,
    desc: "Given N integers, print their sum.",
    ioMode: 'stdio',
    template: makeTemplates(12),
    testCases: [
      { stdin: "3\n1 2 3", expected: "6" },
      { stdin: "1\n100", expected: "100" },
      { stdin: "4\n-1 -2 3 4", expected: "4" },
    ],
  },
  {
    id: 13, title: "Array Max", difficulty: "easy", timeLimit: 300,
    desc: "Print max of N integers.",
    ioMode: 'stdio',
    template: makeTemplates(13),
    testCases: [
      { stdin: "4\n1 5 2 4", expected: "5" },
      { stdin: "1\n-7", expected: "-7" },
      { stdin: "3\n9 9 9", expected: "9" },
    ],
  },
  {
    id: 14, title: "Count Positives", difficulty: "easy", timeLimit: 300,
    desc: "Count positive numbers in array.",
    ioMode: 'stdio',
    template: makeTemplates(14),
    testCases: [
      { stdin: "5\n1 -2 3 -4 5", expected: "3" },
      { stdin: "3\n-1 -2 -3", expected: "0" },
      { stdin: "2\n0 5", expected: "1" },
    ],
  },
  {
    id: 15, title: "Second Largest", difficulty: "easy", timeLimit: 300,
    desc: "Print second largest distinct element.",
    ioMode: 'stdio',
    template: makeTemplates(15),
    testCases: [
      { stdin: "4\n3 1 4 2", expected: "3" },
      { stdin: "3\n10 5 8", expected: "8" },
      { stdin: "2\n1 2", expected: "1" },
    ],
  },
  {
    id: 16, title: "Leap Year", difficulty: "easy", timeLimit: 300,
    desc: "Check if year Y is a leap year. Print YES or NO.",
    ioMode: 'stdio',
    template: makeTemplates(16),
    testCases: [
      { stdin: "2000", expected: "YES" },
      { stdin: "1900", expected: "NO" },
      { stdin: "2024", expected: "YES" },
    ],
  },
  {
    id: 17, title: "Swap Case", difficulty: "easy", timeLimit: 300,
    desc: "Swap case of each letter.",
    ioMode: 'stdio',
    template: makeTemplates(17),
    testCases: [
      { stdin: "Hello", expected: "hELLO" },
      { stdin: "AbC", expected: "aBc" },
      { stdin: "xyz", expected: "XYZ" },
    ],
  },
  {
    id: 18, title: "Digit Sum", difficulty: "easy", timeLimit: 300,
    desc: "Sum of digits of N.",
    ioMode: 'stdio',
    template: makeTemplates(18),
    testCases: [
      { stdin: "123", expected: "6" },
      { stdin: "9999", expected: "36" },
      { stdin: "0", expected: "0" },
    ],
  },
  {
    id: 19, title: "Multiplication Table", difficulty: "easy", timeLimit: 300,
    desc: "Print table of N from 1 to 10, one 'N x i = R' per line.",
    ioMode: 'stdio',
    template: makeTemplates(19),
    testCases: [
      { stdin: "2", expected: "2 x 1 = 2\n2 x 2 = 4\n2 x 3 = 6\n2 x 4 = 8\n2 x 5 = 10\n2 x 6 = 12\n2 x 7 = 14\n2 x 8 = 16\n2 x 9 = 18\n2 x 10 = 20" },
      { stdin: "3", expected: "3 x 1 = 3\n3 x 2 = 6\n3 x 3 = 9\n3 x 4 = 12\n3 x 5 = 15\n3 x 6 = 18\n3 x 7 = 21\n3 x 8 = 24\n3 x 9 = 27\n3 x 10 = 30" },
      { stdin: "1", expected: "1 x 1 = 1\n1 x 2 = 2\n1 x 3 = 3\n1 x 4 = 4\n1 x 5 = 5\n1 x 6 = 6\n1 x 7 = 7\n1 x 8 = 8\n1 x 9 = 9\n1 x 10 = 10" },
    ],
  },
  {
    id: 20, title: "Power", difficulty: "easy", timeLimit: 300,
    desc: "Compute A^B mod 1000000007.",
    ioMode: 'stdio',
    template: makeTemplates(20),
    testCases: [
      { stdin: "2 10", expected: "1024" },
      { stdin: "3 3", expected: "27" },
      { stdin: "5 0", expected: "1" },
    ],
  },
  {
    id: 21, title: "Two Sum", difficulty: "medium", timeLimit: 420,
    desc: "Find indices (1-based) of two numbers summing to target.",
    ioMode: 'stdio',
    template: makeTemplates(21),
    testCases: [
      { stdin: "4 9\n2 7 11 15", expected: "1 2" },
      { stdin: "3 8\n1 5 3", expected: "2 3" },
      { stdin: "2 3\n1 2", expected: "1 2" },
    ],
  },
  {
    id: 22, title: "Binary Search", difficulty: "medium", timeLimit: 420,
    desc: "Find index (1-based) of X in sorted array, or -1.",
    ioMode: 'stdio',
    template: makeTemplates(22),
    testCases: [
      { stdin: "5 3\n1 2 3 4 5", expected: "3" },
      { stdin: "4 10\n1 2 3 4", expected: "-1" },
      { stdin: "3 1\n1 2 3", expected: "1" },
    ],
  },
  {
    id: 23, title: "Merge Sorted Arrays", difficulty: "medium", timeLimit: 420,
    desc: "Merge two sorted arrays into one sorted array.",
    ioMode: 'stdio',
    template: makeTemplates(23),
    testCases: [
      { stdin: "3 3\n1 3 5\n2 4 6", expected: "1 2 3 4 5 6" },
      { stdin: "2 1\n1 2\n3", expected: "1 2 3" },
      { stdin: "1 1\n5\n1", expected: "1 5" },
    ],
  },
  {
    id: 24, title: "Longest Word", difficulty: "medium", timeLimit: 420,
    desc: "Print the longest word in a sentence (first if ties).",
    ioMode: 'stdio',
    template: makeTemplates(24),
    testCases: [
      { stdin: "the quick brown fox", expected: "quick" },
      { stdin: "hi there", expected: "there" },
      { stdin: "a bb ccc", expected: "ccc" },
    ],
  },
  {
    id: 25, title: "Anagram Check", difficulty: "medium", timeLimit: 420,
    desc: "Check if two strings are anagrams. Print YES/NO.",
    ioMode: 'stdio',
    template: makeTemplates(25),
    testCases: [
      { stdin: "listen\nsilent", expected: "YES" },
      { stdin: "hello\nworld", expected: "NO" },
      { stdin: "abc\ncba", expected: "YES" },
    ],
  },
  {
    id: 26, title: "Count Distinct", difficulty: "medium", timeLimit: 420,
    desc: "Count distinct elements in array.",
    ioMode: 'stdio',
    template: makeTemplates(26),
    testCases: [
      { stdin: "5\n1 2 2 3 3", expected: "3" },
      { stdin: "3\n1 2 3", expected: "3" },
    ],
  },
  {
    id: 27, title: "Matrix Transpose", difficulty: "medium", timeLimit: 420,
    desc: "Print transpose of R x C matrix.",
    ioMode: 'stdio',
    template: makeTemplates(27),
    testCases: [
      { stdin: "2 3\n1 2 3\n4 5 6", expected: "1 4\n2 5\n3 6" },
      { stdin: "1 2\n5 6", expected: "5\n6" },
      { stdin: "2 2\n1 2\n3 4", expected: "1 3\n2 4" },
    ],
  },
  {
    id: 28, title: "Bracket Matching", difficulty: "medium", timeLimit: 420,
    desc: "Check balanced (){}[]. Print YES/NO.",
    ioMode: 'stdio',
    template: makeTemplates(28),
    testCases: [
      { stdin: "()[]{}", expected: "YES" },
      { stdin: "([)]", expected: "NO" },
      { stdin: "{[()]}", expected: "YES" },
    ],
  },
  {
    id: 29, title: "Sliding Window Max Sum", difficulty: "medium", timeLimit: 420,
    desc: "Max sum of any K consecutive elements.",
    ioMode: 'stdio',
    template: makeTemplates(29),
    testCases: [
      { stdin: "5 2\n1 2 3 4 5", expected: "9" },
      { stdin: "4 1\n-1 -2 -3 -4", expected: "-1" },
      { stdin: "3 3\n1 2 3", expected: "6" },
    ],
  },
  {
    id: 30, title: "Sort by Frequency", difficulty: "medium", timeLimit: 420,
    desc: "Sort array by frequency desc, break ties by value asc.",
    ioMode: 'stdio',
    template: makeTemplates(30),
    testCases: [
      { stdin: "6\n1 1 2 2 2 3", expected: "2 2 2 1 1 3" },
      { stdin: "4\n4 3 2 1", expected: "1 2 3 4" },
      { stdin: "5\n5 5 4 4 3", expected: "4 4 5 5 3" },
    ],
  },
  {
    id: 31, title: "Longest Increasing Subsequence", difficulty: "hard", timeLimit: 600,
    desc: "Find length of LIS in O(N log N).",
    ioMode: 'stdio',
    template: makeTemplates(31),
    testCases: [
      { stdin: "7\n10 9 2 5 3 7 101", expected: "4" },
      { stdin: "5\n1 2 3 4 5", expected: "5" },
      { stdin: "4\n5 4 3 2", expected: "1" },
    ],
  },
  {
    id: 32, title: "Dijkstra Shortest Path", difficulty: "hard", timeLimit: 600,
    desc: "Shortest path from node 1 to N in weighted undirected graph.",
    ioMode: 'stdio',
    template: makeTemplates(32),
    testCases: [
      { stdin: "4 4\n1 2 1\n2 3 2\n3 4 1\n1 4 10", expected: "4" },
      { stdin: "3 1\n1 2 5", expected: "-1" },
      { stdin: "2 1\n1 2 7", expected: "7" },
    ],
  },
  {
    id: 33, title: "Edit Distance", difficulty: "hard", timeLimit: 600,
    desc: "Min edits (insert/delete/replace) to convert A to B.",
    ioMode: 'stdio',
    template: makeTemplates(33),
    testCases: [
      { stdin: "kitten\nsitting", expected: "3" },
      { stdin: "abc\nabc", expected: "0" },
      { stdin: "a\nab", expected: "1" },
    ],
  },
  {
    id: 34, title: "N-Queens Count", difficulty: "hard", timeLimit: 600,
    desc: "Count distinct solutions to N-Queens.",
    ioMode: 'stdio',
    template: makeTemplates(34),
    testCases: [
      { stdin: "4", expected: "2" },
      { stdin: "1", expected: "1" },
      { stdin: "8", expected: "92" },
    ],
  },
  {
    id: 35, title: "Segment Tree Range Sum", difficulty: "hard", timeLimit: 600,
    desc: "Support point updates and range sum queries.",
    ioMode: 'stdio',
    template: makeTemplates(35),
    testCases: [
      { stdin: "5 3\n1 2 3 4 5\n2 1 5\n1 3 10\n2 1 5", expected: "15\n22" },
      { stdin: "3 2\n1 1 1\n2 1 3\n2 2 2", expected: "3\n1" },
      { stdin: "4 1\n1 2 3 4\n2 2 4", expected: "9" },
    ],
  },
];

const CHALLENGE_MAP = new Map(CHALLENGES.map(c => [c.id, c]));

// Safe challenge data for clients — no expected values
function safeChallenge(c) {
  return {
    id        : c.id,
    title     : c.title,
    desc      : c.desc,
    difficulty: c.difficulty,
    timeLimit : c.timeLimit,
    template  : c.template,
    testInputs: c.testCases.map(tc => tc.stdin ?? tc.input), // inputs visible, expected hidden
  };
}

// ─── Rate Limiter ────────────────────────────────────────────
const RATE_WINDOW  = 10_000;
const RATE_MAX     = 5;

class RateLimiter {
  constructor() { this._m = new Map(); }
  allow(id) {
    const now = Date.now();
    const r   = this._m.get(id) || { n: 0, start: now };
    if (now - r.start > RATE_WINDOW) { r.n = 0; r.start = now; }
    r.n++;
    this._m.set(id, r);
    return r.n <= RATE_MAX;
  }
  del(id) { this._m.delete(id); }
}

// ─── Evaluation Queue ────────────────────────────────────────
// Chains promises per socket — second Submit waits for first to finish
class EvalQueue {
  constructor() { this._m = new Map(); }
  enqueue(id, fn) {
    const prev = this._m.get(id) || Promise.resolve();
    const next = prev.then(() => fn()).catch(() => {});
    this._m.set(id, next);
    return next;
  }
  del(id) { this._m.delete(id); }
}

// ─── Battle State ─────────────────────────────────────────────
function defaultPlayers(count = 2) {
  return PLAYER_KEYS.slice(0, count).map((player, i) => ({
    slot: String(i + 1),
    player,
    name: `PLAYER ${i + 1}`,
  }));
}

function makePlayerMap(value) {
  return Object.fromEntries(PLAYER_KEYS.map(player => [player, value]));
}

function createRegistration(player, name = '') {
  return {
    player,
    name,
    status: 'unregistered',
    socketId: null,
    requestedAt: null,
    approvedAt: null,
    joined: false,
  };
}

function makeRegistrationMap(players = defaultPlayers(2)) {
  const regs = Object.fromEntries(PLAYER_KEYS.map(player => [player, createRegistration(player)]));
  players.forEach(({ player, name }) => {
    regs[player] = createRegistration(player, name);
  });
  return regs;
}

function activePlayers() {
  return state.players?.length ? state.players : defaultPlayers(2);
}

function activePlayerKeys() {
  return activePlayers().map(p => p.player);
}

function activeParticipantKeys() {
  return activePlayers()
    .map(p => p.player)
    .filter(player => state.registrations?.[player]?.status === 'approved');
}

function playerKeyFromSlot(slot) {
  const n = Number(slot);
  return Number.isInteger(n) && n >= 1 && n <= MAX_PLAYERS ? `p${n}` : null;
}

function playerByKey(player) {
  return activePlayers().find(p => p.player === player);
}

function playerDisplayName(player) {
  return state.registrations?.[player]?.name || playerByKey(player)?.name || player.toUpperCase();
}

function normalizePlayers(data = {}) {
  const incoming = Array.isArray(data.players) ? data.players : [
    { slot: '1', name: data.p1Name },
    { slot: '2', name: data.p2Name },
  ];
  const seen = new Set();
  const players = [];

  incoming.forEach((raw, i) => {
    if (players.length >= MAX_PLAYERS) return;
    const slot = String(raw?.slot || i + 1);
    const player = playerKeyFromSlot(slot);
    if (!player || seen.has(player)) return;
    seen.add(player);
    players.push({
      slot: String(Number(slot)),
      player,
      name: String(raw?.name || `PLAYER ${Number(slot)}`).trim().slice(0, 30) || `PLAYER ${Number(slot)}`,
    });
  });

  return players.length >= 2 ? players : defaultPlayers(2);
}

function legacyNameFields(players) {
  return Object.fromEntries(players.map(p => [`${p.player}Name`, playerDisplayName(p.player)]));
}

function publicState() {
  return {
    ...state,
    leaderboard,
    displayNames: Object.fromEntries(activePlayers().map(p => [p.player, playerDisplayName(p.player)])),
    registrations: Object.fromEntries(
      Object.entries(state.registrations || {}).map(([player, reg]) => [player, reg ? {
        player: reg.player,
        name: reg.name,
        status: reg.status,
        requestedAt: reg.requestedAt,
        approvedAt: reg.approvedAt,
        joined: reg.joined,
      } : null])
    ),
    ...legacyNameFields(activePlayers()),
  };
}

function setPlayerName(player, name) {
  const clean = String(name || '').trim().slice(0, 30);
  if (!clean) return;
  state.players = activePlayers().map(p => p.player === player ? { ...p, name: clean } : p);
  if (state.registrations?.[player]) state.registrations[player].name = clean;
}

function emitStateSync(target = io) {
  const ch = state.challengeId ? CHALLENGE_MAP.get(state.challengeId) : null;
  target.emit('state_sync', { ...publicState(), challengeData: ch ? safeChallenge(ch) : null });
}

function emitRegistrationUpdate(player) {
  io.emit('registration_update', {
    player,
    registration: state.registrations?.[player] || null,
    players: activePlayers(),
  });
}

let state = {
  players: defaultPlayers(2),
  challengeId: null, timeLimit: 0,
  timers    : makePlayerMap(0),
  status    : makePlayerMap('idle'),
  finishTime: makePlayerMap(null),
  codeByPlayer: makePlayerMap(''),
  languageByPlayer: makePlayerMap('javascript'),
  registrations: makeRegistrationMap(defaultPlayers(2)),
  running: false, paused: false,
};
let timerIntervals = makePlayerMap(null);
let leaderboard = [];
let roundCounter = 0;

// ─── Timer helpers ────────────────────────────────────────────
function tickTimer(player) {
  clearInterval(timerIntervals[player]);
  timerIntervals[player] = setInterval(() => {
    if (state.timers[player] <= 0) {
      clearInterval(timerIntervals[player]);
      markOut(player);
      return;
    }
    state.timers[player]--;
    io.emit('timer_tick', { player, remaining: state.timers[player], danger: state.timers[player] <= 30 });
  }, 1000);
}

function markOut(player) {
  if (!activeParticipantKeys().includes(player)) return;
  if (state.status[player] === 'solved' || state.status[player] === 'out') return;
  clearInterval(timerIntervals[player]);
  state.timers[player] = 0;
  state.status[player] = 'out';
  log('info', 'player_out', { player });
  io.emit('player_out', { player });
  checkAllDone();
}

function checkAllDone() {
  const participants = activeParticipantKeys();
  if (participants.length && participants.every(player => state.status[player] === 'solved' || state.status[player] === 'out')) {
    declareWinner();
  }
}

function declareWinner() {
  const participants = activeParticipantKeys();
  participants.forEach(player => clearInterval(timerIntervals[player]));
  state.running = false;
  const solved = participants
    .filter(player => state.status[player] === 'solved')
    .sort((a, b) => state.finishTime[a] - state.finishTime[b]);
  const winner = solved[0] || null;
  const ch = state.challengeId ? CHALLENGE_MAP.get(state.challengeId) : null;
  const entry = {
    round: ++roundCounter,
    endedAt: Date.now(),
    challengeId: state.challengeId,
    challengeTitle: ch?.title || 'Unknown challenge',
    playerCount: participants.length,
    players: participants.map(player => ({
      player,
      name: playerDisplayName(player),
      status: state.status[player],
      finishTime: state.finishTime[player],
    })),
    winner,
    winnerName: winner ? playerDisplayName(winner) : null,
  };
  leaderboard = [entry, ...leaderboard].slice(0, 30);
  log('info', 'winner_declared', { winner });
  io.emit('winner', { winner, winnerName: entry.winnerName, players: activePlayers(), ...legacyNameFields(activePlayers()), finishTime: state.finishTime, leaderboard });
  emitStateSync();
}

// ─── Express + Socket.io ─────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors        : { origin: CORS_ORIGIN, methods: ['GET', 'POST'] },
  pingTimeout : 60_000,
  pingInterval: 25_000,
});

app.use(express.static(path.join(__dirname)));

app.get('/health', (_, res) => res.json({
  status: 'ok', uptime: process.uptime(),
  memory: process.memoryUsage(), ts: new Date().toISOString(),
}));

app.get('/api/challenges', (_, res) =>
  res.json(CHALLENGES.map(safeChallenge))
);

// ─── Rate limiter + eval queue ───────────────────────────────
const rateLimiter = new RateLimiter();
const evalQueue   = new EvalQueue();

// ─── Socket.io ───────────────────────────────────────────────
io.on('connection', (socket) => {
  const role = socket.handshake.query.role || 'unknown';
  log('info', 'connect', { socketId: socket.id, role });

  // Send current state to newly connected client (no expected values)
  emitStateSync(socket);

  // ── HOST ─────────────────────────────────────────────────
  socket.on('setup', (data) => {
    const ch = CHALLENGE_MAP.get(Number(data.challengeId));
    if (!ch) { socket.emit('error_event', { message: `Unknown challenge id: ${data.challengeId}` }); return; }
    const tl = (data.timeLimit > 0 && data.timeLimit <= 7200) ? data.timeLimit : ch.timeLimit;
    const players = normalizePlayers(data);
    activePlayerKeys().forEach(player => clearInterval(timerIntervals[player]));

    state = {
      players,
      challengeId: ch.id, timeLimit: tl,
      timers     : { ...makePlayerMap(0), ...Object.fromEntries(players.map(p => [p.player, tl])) },
      status     : { ...makePlayerMap('idle'), ...Object.fromEntries(players.map(p => [p.player, 'idle'])) },
      finishTime : makePlayerMap(null),
      codeByPlayer: makePlayerMap(''),
      languageByPlayer: makePlayerMap('javascript'),
      registrations: makeRegistrationMap(players),
      running: false, paused: false,
    };

    log('info', 'battle_setup', { challengeId: ch.id, title: ch.title, tl, players });
    io.emit('setup', { players, ...legacyNameFields(players), challengeData: safeChallenge(ch), timeLimit: tl });
    emitStateSync();
  });

  socket.on('start', () => {
    if (state.running) return;
    const participants = activeParticipantKeys();
    if (!participants.length) {
      socket.emit('error_event', { message: 'Approve at least one player before starting the battle.' });
      return;
    }
    state.running = true; state.paused = false;
    activePlayerKeys().forEach(player => { state.status[player] = participants.includes(player) ? 'coding' : 'idle'; });
    log('info', 'battle_start', { challengeId: state.challengeId });
    io.emit('battle_start', { timeLimit: state.timeLimit });
    participants.forEach(tickTimer);
    emitStateSync();
  });

  socket.on('pause', () => {
    if (!state.running || state.paused) return;
    state.paused = true;
    activePlayerKeys().forEach(player => clearInterval(timerIntervals[player]));
    log('info', 'battle_pause');
    io.emit('battle_pause');
  });

  socket.on('resume', () => {
    if (!state.running || !state.paused) return;
    state.paused = false;
    activePlayerKeys().forEach(player => { if (state.status[player] === 'coding') tickTimer(player); });
    log('info', 'battle_resume');
    io.emit('battle_resume');
  });

  socket.on('reset', () => {
    activePlayerKeys().forEach(player => clearInterval(timerIntervals[player]));
    state.timers = { ...makePlayerMap(0), ...Object.fromEntries(activePlayerKeys().map(player => [player, state.timeLimit])) };
    state.status = { ...makePlayerMap('idle'), ...Object.fromEntries(activePlayerKeys().map(player => [player, 'idle'])) };
    state.finishTime = makePlayerMap(null);
    state.codeByPlayer = makePlayerMap('');
    state.languageByPlayer = makePlayerMap('javascript');
    activePlayerKeys().forEach(player => {
      if (state.registrations[player]) {
        state.registrations[player].status = 'rejected';
        state.registrations[player].approvedAt = null;
        state.registrations[player].joined = false;
      }
    });
    state.running = false; state.paused = false;
    log('info', 'battle_reset');
    io.emit('battle_reset', { timeLimit: state.timeLimit, players: activePlayers() });
    emitStateSync();
  });

  socket.on('delete_leaderboard_entry', ({ round }) => {
    if (role !== 'host') {
      socket.emit('error_event', { message: 'Only the host can delete leaderboard entries.' });
      return;
    }
    const roundNumber = Number(round);
    if (!Number.isFinite(roundNumber)) {
      socket.emit('error_event', { message: 'Invalid leaderboard entry.' });
      return;
    }
    const before = leaderboard.length;
    leaderboard = leaderboard.filter(entry => entry.round !== roundNumber);
    if (leaderboard.length === before) {
      socket.emit('error_event', { message: `Leaderboard entry #${roundNumber} was not found.` });
      return;
    }
    log('info', 'leaderboard_entry_deleted', { round: roundNumber });
    emitStateSync();
  });

  socket.on('host_mark_solved', ({ player }) => {
    if (!activeParticipantKeys().includes(player)) return;
    if (state.status[player] === 'solved' || state.status[player] === 'out') return;
    clearInterval(timerIntervals[player]);
    const used = state.timeLimit - state.timers[player];
    state.status[player] = 'solved'; state.finishTime[player] = used;
    log('info', 'host_mark_solved', { player, used });
    io.emit('player_solved', { player, timeUsed: used });
    checkAllDone();
  });

  socket.on('host_mark_out', ({ player }) => markOut(player));

  socket.on('host_set_registration', ({ player, status }) => {
    if (!activePlayerKeys().includes(player)) return;
    if (state.running) {
      socket.emit('error_event', { message: 'Pause or reset the battle before changing payment approvals.' });
      return;
    }
    const reg = state.registrations?.[player];
    if (!reg) return;
    reg.status = status === 'approved' ? 'approved' : 'rejected';
    reg.approvedAt = status === 'approved' ? Date.now() : null;
    reg.joined = false;
    if (!reg.name) reg.name = playerByKey(player)?.name || player.toUpperCase();
    setPlayerName(player, reg.name);
    log('info', 'registration_status_set', { player, status: reg.status });
    emitRegistrationUpdate(player);
    emitStateSync();
    if (reg.socketId) {
      io.to(reg.socketId).emit('registration_status', { player, registration: reg });
    }
  });

  // ── PLAYER ───────────────────────────────────────────────
  socket.on('check_registration', ({ slot }) => {
    const player = playerKeyFromSlot(slot);
    const reg = player ? state.registrations?.[player] : null;
    socket.emit('registration_status', { player, registration: reg || null });
  });

  socket.on('register_player', ({ slot, name }) => {
    const player = playerKeyFromSlot(slot);
    if (!player || !activePlayerKeys().includes(player)) {
      socket.emit('registration_status', {
        player,
        registration: { status: 'rejected', name: '', joined: false },
        error: `Slot ${slot} is not available for this battle.`,
      });
      return;
    }
    const reg = state.registrations[player] || createRegistration(player);
    reg.socketId = socket.id;
    reg.joined = false;
    if (name) {
      reg.name = String(name).trim().slice(0, 30) || reg.name;
      setPlayerName(player, reg.name);
    }
    if (reg.status !== 'approved') {
      reg.status = 'pending';
      reg.requestedAt = Date.now();
      reg.approvedAt = null;
    }
    state.registrations[player] = reg;
    log('info', 'registration_requested', { slot, player, name: reg.name, status: reg.status });
    emitRegistrationUpdate(player);
    emitStateSync();
    socket.emit('registration_status', { player, registration: reg });
  });

  socket.on('player_connected', ({ slot }) => {
    const player = playerKeyFromSlot(slot);
    const reg = player ? state.registrations?.[player] : null;
    if (!player || !reg || reg.status !== 'approved') {
      socket.emit('error_event', { message: 'Registration is pending admin approval.' });
      socket.emit('registration_status', { player, registration: reg || null });
      return;
    }
    reg.socketId = socket.id;
    reg.joined = true;
    log('info', 'player_connected', { slot, socketId: socket.id });
    io.emit('player_connected', { slot });
    emitRegistrationUpdate(player);
    emitStateSync(socket);
  });

  // Live code relay to host (no evaluation here)
  socket.on('code_update', ({ slot, code, language = 'javascript' }) => {
    const player = playerKeyFromSlot(slot);
    if (!player || state.registrations?.[player]?.status !== 'approved') return;
    state.codeByPlayer[player] = String(code || '').slice(0, 100_000);
    state.languageByPlayer[player] = language;
    io.emit('code_update', { slot, code, language });
  });

  // ── SERVER-SIDE EVALUATION ───────────────────────────────
  socket.on('submit_code', (data) => {
    const { slot, code, language = 'javascript', isRun = false } = data;
    const player   = playerKeyFromSlot(slot);
    const submitId = crypto.randomBytes(6).toString('hex');
    if (player) {
      state.codeByPlayer[player] = String(code || '').slice(0, 100_000);
      state.languageByPlayer[player] = language;
    }

    // Rate limit
    if (!rateLimiter.allow(socket.id)) {
      log('warn', 'rate_limited', { socketId: socket.id, slot });
      socket.emit('eval_result', {
        submitId, slot, isRun,
        error: 'Too many submissions. Wait a few seconds.',
        allPassed: false, results: [],
      });
      return;
    }

    // Must have active challenge
    const ch = CHALLENGE_MAP.get(state.challengeId);
    if (!ch) {
      socket.emit('eval_result', { submitId, slot, isRun, error: 'No active challenge.', allPassed: false, results: [] });
      return;
    }

    if (!player || !playerByKey(player)) {
      socket.emit('eval_result', { submitId, slot, isRun, error: `Player slot ${slot} is not active for this battle.`, allPassed: false, results: [] });
      return;
    }
    if (state.registrations?.[player]?.status !== 'approved') {
      socket.emit('eval_result', { submitId, slot, isRun, error: 'Payment approval is still pending.', allPassed: false, results: [] });
      return;
    }

    // Coding status check (only for submit, not run)
    if (!isRun && state.status[player] !== 'coding') {
      socket.emit('eval_result', {
        submitId, slot, isRun,
        error: `Cannot submit — player status is "${state.status[player]}".`,
        allPassed: false, results: [],
      });
      return;
    }

    log('info', 'submit_received', { submitId, slot, language, challengeId: ch.id, codeLen: code?.length, isRun });

    // Queue evaluation — serialises concurrent submits from same socket
    evalQueue.enqueue(socket.id, async () => {
      const t0 = Date.now();

      const evalOptions = { timeoutMs: 3000, challengeId: ch.id, stdio: ch.ioMode === 'stdio' };
      const evalResult = language === 'python'
        ? await runPython(code, ch.testCases, evalOptions)
        : language === 'c'
          ? await runC(code, ch.testCases, evalOptions)
          : language === 'cpp'
            ? await runCpp(code, ch.testCases, evalOptions)
            : ch.ioMode === 'stdio'
              ? await runJavaScriptStdio(code, ch.testCases, evalOptions)
              : runAllTestCases(code, ch.testCases, { timeoutMs: 3000 });

      log('info', 'eval_complete', {
        submitId, slot, challengeId: ch.id, isRun,
        allPassed: evalResult.allPassed,
        totalMs  : evalResult.totalTimeMs,
        elapsed  : Date.now() - t0,
        passed   : evalResult.results.filter(r => r.passed).length,
        total    : evalResult.results.length,
        syntaxErr: evalResult.syntaxError || null,
      });

      // Send result to this player only
      socket.emit('eval_result', {
        submitId, slot, isRun,
        allPassed  : evalResult.allPassed,
        syntaxError: evalResult.syntaxError,
        totalTimeMs: evalResult.totalTimeMs,
        results    : evalResult.results.map(r => ({
          testNum    : r.testNum,
          passed     : r.passed,
          reason     : r.reason,
          inputStr   : r.inputStr,
          expectedStr: r.expectedStr,
          actualStr  : r.actualStr,
          timeMs     : r.timeMs,
          error      : r.error,
          logs       : r.logs,
        })),
      });

      // Auto-mark solved on the server (only for submit, not run)
      if (!isRun && evalResult.allPassed) {
        if (state.status[player] === 'solved' || state.status[player] === 'out') return;
        clearInterval(timerIntervals[player]);
        const used = state.timeLimit - state.timers[player];
        state.status[player] = 'solved'; state.finishTime[player] = used;
        log('info', 'player_solved_auto', { slot, player, used, submitId });
        io.emit('player_solved', { player, timeUsed: used });
        checkAllDone();
      }
    });
  });

  socket.on('disconnect', () => {
    log('info', 'disconnect', { socketId: socket.id, role });
    activePlayerKeys().forEach(player => {
      const reg = state.registrations?.[player];
      if (reg?.socketId === socket.id) {
        reg.joined = false;
      }
    });
    rateLimiter.del(socket.id);
    evalQueue.del(socket.id);
  });
});

// ─── Global crash guards ─────────────────────────────────────
process.on('uncaughtException', (err) => {
  log('error', 'uncaught_exception', { message: err.message, stack: err.stack });
  if (NODE_ENV === 'production') process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  log('error', 'unhandled_rejection', { reason: String(reason) });
});

// ─── Start ───────────────────────────────────────────────────
server.listen(PORT, () => {
  log('info', 'server_started', { port: PORT, env: NODE_ENV, cors: CORS_ORIGIN });
  console.log(`\n🚀  CODE COMBAT v2.0  →  http://localhost:${PORT}`);
  console.log(`   Host     →  http://localhost:${PORT}/coding-combat-host.html`);
  for (let i = 1; i <= MAX_PLAYERS; i++) {
    console.log(`   Player ${i} →  http://localhost:${PORT}/coding-combat-player.html?slot=${i}`);
  }
  console.log(`   Health   →  http://localhost:${PORT}/health\n`);
});
